class Patient {
	constructor (newId, newLastName, newFirstName, newFeesOwing, theDoctor) {
    // ADD CODE HERE
	
	}
}