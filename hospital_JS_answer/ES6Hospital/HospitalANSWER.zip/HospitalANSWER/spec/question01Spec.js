/*global describe beforeEach Controller it expect Hospital Doctor Patient*/
describe('Question One', () => {
    describe('Draw a class diagram', () => {})
})